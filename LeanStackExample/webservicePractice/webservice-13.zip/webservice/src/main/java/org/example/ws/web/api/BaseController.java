package org.example.ws.web.api;

public class BaseController {

}
