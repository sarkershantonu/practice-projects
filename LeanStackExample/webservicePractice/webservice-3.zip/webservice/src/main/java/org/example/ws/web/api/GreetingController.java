package org.example.ws.web.api;

import java.math.BigInteger;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import javax.swing.text.html.FormSubmitEvent.MethodType;

import org.aspectj.bridge.Message;
import org.example.ws.model.Greeting;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.w3c.dom.stylesheets.MediaList;

@RestController
public class GreetingController {
	private static Map<BigInteger, Greeting> greetings;
	private static BigInteger index;

	static {
		Greeting g1 = new Greeting();
		g1.setText("First");
		save(g1);
		Greeting g2 = new Greeting();
		g2.setText("2nd");
		save(g2);
	}

	private static boolean del(BigInteger id) {
		Greeting deleted = greetings.remove(id); 
		if (deleted==null)
			return false;
		return true;
	}

	private static Greeting save(Greeting g) {

		if (greetings == null) {
			greetings = new HashMap<BigInteger, Greeting>();
			index = BigInteger.ONE;
		}
		if (g.getId() != null) {
			Greeting oldGreet = greetings.get(g.getId());
			if (oldGreet == null) {
				return null;
			}
			greetings.remove(g.getId());
			greetings.put(g.getId(), g);
			return g;
		}
		g.setId(index);
		index = index.add(BigInteger.ONE); // increment
		greetings.put(g.getId(), g);
		return g;
	}

	@RequestMapping(value = "/api/greetings", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Collection<Greeting>> getAllGreeting() {
		Collection<Greeting> greets = greetings.values();
		return new ResponseEntity<Collection<Greeting>>(greets, HttpStatus.OK);

	}

	@RequestMapping(value = "/api/greetings/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Greeting> getGreeting(@PathVariable("id") BigInteger id) {
		Greeting greet = greetings.get(id);
		if (greet == null) {
			return new ResponseEntity<Greeting>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Greeting>(greet, HttpStatus.OK);
	}

	@RequestMapping(value = "/api/greetings", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Greeting> addGreeting(@RequestBody Greeting g) {
		Greeting saved = save(g);
		return new ResponseEntity<Greeting>(saved, HttpStatus.CREATED);
	}

	@RequestMapping(value = "/api/greetings/{id}", method = RequestMethod.DELETE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Greeting> delGreeting(@PathVariable("id") BigInteger id, @RequestBody Greeting g) {
		boolean result = del(id);
		if (!result) {
			new ResponseEntity<Greeting>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return new ResponseEntity<Greeting>(HttpStatus.NO_CONTENT);
	}

	@RequestMapping(value = "/api/greetings/{id}", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Greeting> update(@RequestBody Greeting g, @PathVariable("id") BigInteger id) {
		Greeting update;
		if (id.equals(g.getId())) {// checking if item is putting in right path
			update = save(g);
		} else {
			return new ResponseEntity<Greeting>(HttpStatus.NOT_FOUND);
		}
		if (update == null) {
			return new ResponseEntity<Greeting>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Greeting>(update, HttpStatus.ACCEPTED);
	}

}
