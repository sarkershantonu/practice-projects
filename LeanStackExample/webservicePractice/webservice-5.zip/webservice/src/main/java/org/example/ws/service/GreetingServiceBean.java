package org.example.ws.service;

import java.util.Collection;

import org.example.ws.model.Greeting;
import org.example.ws.repository.GreetingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class GreetingServiceBean implements GreetingService{

	@Autowired
	private GreetingRepository greetingRepository; 
	
		
	@Override
	public Collection<Greeting> findAll() {
		Collection<Greeting> greetings = greetingRepository.findAll();
		return greetings;
	}

	@Override
	public Greeting findOne(Long id) {
		Greeting greeting = greetingRepository.findOne(id);
		return greeting;
	}

	@Override
	public Greeting create(Greeting g) {
		
		if(g.getId()!=null){
			return null; 
		}
		Greeting savedgreeting = greetingRepository.save(g);
		return savedgreeting;
	}

	@Override
	public Greeting update(Greeting g) {
		Greeting got = findOne(g.getId()); 
		if(got==null){// not in DB
			return null; 
		}
		Greeting updatedgreeting = greetingRepository.save(g);
		return updatedgreeting;
	}
	@Override
	public void delete(Long id) {
		greetingRepository.delete(id);
		
	}
	
}
