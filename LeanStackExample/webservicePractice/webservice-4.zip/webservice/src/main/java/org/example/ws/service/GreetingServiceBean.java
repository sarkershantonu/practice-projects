package org.example.ws.service;

import java.math.BigInteger;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.example.ws.model.Greeting;
import org.springframework.stereotype.Service;

@Service
public class GreetingServiceBean implements GreetingService{

	private static Map<BigInteger, Greeting> greetings;
	private static BigInteger index;

	static {
		Greeting g1 = new Greeting();
		g1.setText("First");
		save(g1);
		Greeting g2 = new Greeting();
		g2.setText("2nd");
		save(g2);
	}

	private static boolean remove(BigInteger id) {
		Greeting deleted = greetings.remove(id); 
		if (deleted==null)
			return false;
		return true;
	}

	private static Greeting save(Greeting g) {

		if (greetings == null) {
			greetings = new HashMap<BigInteger, Greeting>();
			index = BigInteger.ONE;
		}
		if (g.getId() != null) {
			Greeting oldGreet = greetings.get(g.getId());
			if (oldGreet == null) {
				return null;
			}
			greetings.remove(g.getId());
			greetings.put(g.getId(), g);
			return g;
		}
		g.setId(index);
		index = index.add(BigInteger.ONE); // increment
		greetings.put(g.getId(), g);
		return g;
	}
	
	
	@Override
	public Collection<Greeting> findAll() {
		
		return greetings.values();
	}

	@Override
	public Greeting findOne(Long id) {
		Greeting out = greetings.get(BigInteger.valueOf(id));
		return out;
	}

	@Override
	public Greeting create(Greeting g) {
		Greeting saved = save(g);
		return saved;
	}

	@Override
	public Greeting update(Greeting g) {
		Greeting update = save(g);
		return update;
	}
	@Override
	public void delete(Long id) {
		boolean result = remove(BigInteger.valueOf(id));
		
	}


	
	
}
